﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace felveteli
{
    /// <summary>
    /// Interaction logic for UjDiak.xaml
    /// </summary>
    public partial class UjDiak : Window
    {
        Kuldo adatok;

        public UjDiak()
        {
            InitializeComponent();
        }

        private void btnBezar_Click(object sender, RoutedEventArgs e)
        {
           Close();
        }

        public UjDiak(Kuldo ujdiak) : this()
        {
            this.adatok = ujdiak;
        }

        private void btnBekuld_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtOM.Text) || string.IsNullOrEmpty(txtNev.Text) || string.IsNullOrEmpty(txtMatek.Text) || string.IsNullOrEmpty(txtMagyar.Text) || string.IsNullOrEmpty(txtErtesites.Text) || string.IsNullOrEmpty(txtEmail.Text) || string.IsNullOrEmpty(dpSzuletesi.Text))
            {
                MessageBox.Show("Nem adtál meg mindenhova adatot!");
                return;
            }

            if(txtOM.Text.Length == 11 || txtOM.Text[0] == 7)
            {
                adatok.OM_Azonosito = txtOM.Text;
            }

            adatok.Neve = txtNev.Text;
            adatok.ErtesitesiCime = txtErtesites.Text;
            adatok.Email = txtEmail.Text;
            adatok.SzuletesiDatum = Convert.ToDateTime(dpSzuletesi.Text);


            try
            {
                if( Convert.ToInt32(txtMatek.Text) > 50 ||  Convert.ToInt32(txtMatek.Text) < 0)
                {
                    MessageBox.Show("0 és 50 között lehet csak a pontszám!");
                }
                else { adatok.Matematika = Convert.ToInt32(txtMatek.Text); }
                
            }
            catch
            {
                MessageBox.Show("A matematika sorba nem számot írt!");
            }

            try
            {
                if (Convert.ToInt32(txtMagyar.Text) > 50 || Convert.ToInt32(txtMagyar.Text) < 0)
                {
                    MessageBox.Show("0 és 50 között lehet csak a pontszám!");
                }
                else { adatok.Magyar = Convert.ToInt32(txtMagyar.Text); }

            }
            catch
            {
                MessageBox.Show("A magyar sorba nem számot írt!");
            }

            Close();
            
        }
    }
}
