﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace felveteli
{
    public class Kuldo
    {
        string omAzonosito;
        string nev;
        string ertesitesiCim;
        DateTime szuletesiDatum;
        string elerhetosegEmail;
        int matekPontszam;
        int magyarPontszam;
        string telefon;
        string iskola;
        int konnyites;

        public Kuldo(string omAzonosito, string nev, string ertesitesiCim, DateTime szuletesiDatum, string elerhetosegEmail, int matekPontszam, int magyarPontszam, string telefon, string iskola, int konnyites)
        {
            this.omAzonosito = omAzonosito;
            this.nev = nev;
            this.ertesitesiCim = ertesitesiCim;
            this.szuletesiDatum = szuletesiDatum;
            this.elerhetosegEmail = elerhetosegEmail;
            this.matekPontszam = matekPontszam;
            this.magyarPontszam = magyarPontszam;
            this.telefon = telefon;
            this.iskola = iskola;
            this.konnyites = konnyites;
        }

        public string OmAzonosito { get => omAzonosito; set => omAzonosito = value; }
        public string Nev { get => nev; set => nev = value; }
        public string ErtesitesiCim { get => ertesitesiCim; set => ertesitesiCim = value; }
        public DateTime SzuletesiDatum { get => szuletesiDatum; set => szuletesiDatum = value; }
        public string ElerhetosegEmail { get => elerhetosegEmail; set => elerhetosegEmail = value; }
        public int MatekPontszam { get => matekPontszam; set => matekPontszam = value; }
        public int MagyarPontszam { get => magyarPontszam; set => magyarPontszam = value; }
        public string Telefon { get => telefon; set => telefon = value; }
        public string Iskola { get => iskola; set => iskola = value; }
        public int Konnyites { get => konnyites; set => konnyites = value; }
    }
}