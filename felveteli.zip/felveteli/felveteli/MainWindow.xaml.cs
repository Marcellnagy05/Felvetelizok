﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace felveteli
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>+
    public partial class MainWindow : Window
    {
        List<Kuldo> Datas = new List<Kuldo>();
        public MainWindow()
        {
            InitializeComponent();
            ReadData();
        }
        public void ReadData()
        {
            string Data_file = "felvetelizok.csv";
            StreamReader sr = new StreamReader(Data_file);

            sr.ReadLine();

            while (!sr.EndOfStream)
            {
                string[] fields = sr.ReadLine().Split(';');


                Kuldo userData = new Kuldo(
                    omAzonosito: fields[0],
                    nev:fields[1],
                    ertesitesiCim: fields[2],
                    szuletesiDatum:  DateTime.Parse(fields[3]),
                    elerhetosegEmail: fields[4],
                    matekPontszam: int.Parse(fields[5]),
                    magyarPontszam: int.Parse(fields[6]),
                    telefon: fields[7],
                    iskola: fields[8],
                    konnyites: int.Parse(fields[9])
                );

                Datas.Add(userData);
            }
            sr.Close();
            Dg_Students.ItemsSource = Datas;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            UjDiak w = new UjDiak();
            w.ShowDialog();
        }

        private void btnImport_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog fileDialog = new OpenFileDialog();
            if (fileDialog.ShowDialog() == true)
            {
                StreamReader sr = new StreamReader(fileDialog.FileName);

                sr.ReadLine();

                Datas.Clear();
                while (!sr.EndOfStream)
                {
                    string[] fields = sr.ReadLine().Split(';');


                    Kuldo userData = new Kuldo(
                        omAzonosito: fields[0],
                        nev: fields[1],
                        ertesitesiCim: fields[2],
                        szuletesiDatum: DateTime.Parse(fields[3]),
                        elerhetosegEmail: fields[4],
                        matekPontszam: int.Parse(fields[5]),
                        magyarPontszam: int.Parse(fields[6]),
                        telefon: fields[7],
                        iskola: fields[8],
                        konnyites: int.Parse(fields[9])
                    );
                    Datas.Add(userData);
                }
                sr.Close();
                Dg_Students.ItemsSource = Datas;

            }
        }
    }
}
